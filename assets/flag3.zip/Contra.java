public class Contra {

    public static void main(String[] args) {
        int goal = 753;
        System.out.print("sy_");
        System.out.flush();
        String in = readSecret();
        int secret = hashSecret(in);
        if (goal == secret) {
            System.out.println("Good job, Red Falcon!");
            return;
        }

        System.out.println("It seems you're still lost in Galuga");
    }

    private static int hashSecret(String in) {
        return in.toUpperCase()
                .chars()
                .reduce((a, b) -> a + b)
                .getAsInt();
    }

    private static String readSecret() {
        return System.console().readLine();
    }
}

