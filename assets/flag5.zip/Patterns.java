import java.util.Map;
import java.util.Stack;

public class Patterns {

    private static String firstletter(Class clazz){
        return clazz.getSimpleName().substring(0, 1);
    }

    public static void main(String[] args) {
        final StringBuilder sb = new StringBuilder("sy_");
        sb.append(firstletter(X1.class));
        sb.append(firstletter(X2.class));
        sb.append(firstletter(X3.class));
        sb.append(firstletter(X4.class));
        sb.append(firstletter(X5.class));
        sb.append(firstletter(X6.class));
        sb.append(firstletter(X7.class));
        sb.append(firstletter(X8.class));

        System.out.println(sb.toString());
    }

    private class X1 {
        private class X1a {
            private final int x;
            public X1a(final int x) {
                this.x = x;
            }
        }
        private class X1b {
            private int x1b1 = 0;
            public X1a x1b2(){
                return new X1a(x1b1);
            }
            public void x1b3(X1a x1a){
                this.x1b1 = x1a.x;
            }
            public int x1b4(){
                return ++this.x1b1;
            }
        }
        private class X1c {
            public void x1c1(X1b x1b){
                X1a x = x1b.x1b2();
                int y = x1b.x1b4();
                if(y > 42) x1b.x1b3(x);
            }
        }
    }

    private static class X2 {
        private interface X2a {
            Integer x2a1(Map<String, Integer> context);
        }
        private class X2b implements X2a {
            private final X2a x2b1;
            private final X2a x2b2;
            private X2b(X2a x2b1, X2a x2b2) {
                this.x2b1 = x2b1;
                this.x2b2 = x2b2;
            }
            public Integer x2a1(Map<String, Integer> x) {
                return x2b1.x2a1(x) + x2b2.x2a1(x);
            }
        }
        private class X2c implements X2a {
            private final String x2c1;
            private X2c(String x2c1) {
                this.x2c1 = x2c1;
            }
            public Integer x2a1(Map<String, Integer> x) {
                Integer y = x.get(x2c1);
                return y == null ? 0 : y;
            }
        }
    }

    private class X3 {
        private class X3a {
            private X3b x3b;
            private X3c x3c;
            private X3d x3d;
            public void x3a1() {
                if(x3c.x3c3()) {
                    x3c.x3c2();
                    x3d.x3c3("Off");
                } else {
                    x3c.x3c4();
                    x3d.x3c3("On");
                }
            }
            public void x3a2(X3b x3b) {
                this.x3b = x3b;
            }
            public void x3a3(X3c x3c) {
                this.x3c = x3c;
                x3c.x3c2();
            }
            public void x3a4(X3d x3d) {
                this.x3d = x3d;
                x3d.x3c3("Off");
            }
        }
        private class X3b {
            private final X3a x3a;
            public X3b(X3a x3a) {
                this.x3a = x3a;
                x3a.x3a2(this);
            }
            public void x3b1() {
                x3a.x3a1();
            }
        }
        private class X3c {
            private boolean x3c1 = false;
            public X3c(X3a x) {
                x.x3a3(this);
            }
            public boolean x3c3() {
                return this.x3c1;
            }
            public void x3c4(){
                this.x3c1 = true;
            }
            public void x3c2() {
                this.x3c1 = false;
            }
        }
        private class X3d {
            private String x3d1 = "";
            public X3d(X3a x) {
                x.x3a4(this);
            }
            public void x3c3(String x) {
                this.x3d1 = x;
            }
        }
    }

    private class X4 {
        private class X4a {
            private final String x4a1;
            private X4a(String x4a1) {
                this.x4a1 = x4a1;
            }
            public X4b x4b(){
                return new X4b(x4a1.getBytes());
            }
        }
        private class X4b {
            private final byte[] x4b1;
            private int x4b2 = 0;
            public X4b(byte[] x4b1) {
                this.x4b1 = x4b1;
            }
            public boolean x4b3() {
                return x4b2 < x4b1.length;
            }
            public byte x4b5() {
                byte x = x4b1[x4b2];
                x4b2++;
                return x;
            }
        }
    }

    private static class X5 {
        private interface X5a {
            void x5a1();
            void x5a2();
        }
        private class X5b {
            private final Stack<X5a> x5b1 = new Stack<X5a>();
            public void x5b2(X5a x) {
                x.x5a1();
                x5b1.push(x);
            }
            public void x5b3() {
                X5a x = x5b1.pop();
                x.x5a2();
            }
        }
        private class X5c implements X5a {
            public void x5a1() {
                System.out.println("up");
            }
            public void x5a2() {
                System.out.println("down");
            }
        }
        private class x5d implements X5a {
            public void x5a1() {
                System.out.println("down");
            }
            public void x5a2() {
                System.out.println("up");
            }
        }
    }

    private static class X6 {
        private class X6a {
            public String x6a1() {
                return "42";
            }
        }
        private interface X6b {
            Long x6b1();
        }
        private class X6c implements X6b {
            private final X6a x6a;
            private X6c(X6a x6a) {
                this.x6a = x6a;
            }
            public Long x6b1() {
                return Long.valueOf(x6a.x6a1());
            }
        }
        private class X6d {
            void x6d1(X6b x) {
                System.out.println(x.x6b1());
            }
        }
    }

    private class X7 {
        private abstract class X7a {
            protected abstract int x7a1();
            public int x7a2() {
                return x7a1() * 2;
            }
        }
        private class X7b extends X7a {
            protected int x7a1() {
                return 0;
            }
        }
    }

    private static class X8 {
        private static X8 x;
        private X8() {}
        public static X8 x8a() {
            if(x == null) {
                x = new X8();
            }
            return x;
        }
    }
}

